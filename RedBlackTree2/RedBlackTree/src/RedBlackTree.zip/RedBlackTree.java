import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Stack;





public class RedBlackTree <T extends Comparable<? super T>> implements Iterable<T> {
	public int height = -1;
	public BinaryNode root;
	public int count = 0;
	public BinaryNode nullNode = new BinaryNode(); 
	public RedBlackTree(){
		this.root = new BinaryNode();
	}

	public enum Color {
		BLACK, RED

	}
	public int getHeight(BinaryNode a){

		return a == null ? -1 : a.height;
	}
	
	public BinaryNode balance(BinaryNode GGP){
		if(GGP ==  null || GGP.element == null){
			
		}else{
			if(GGP.leftChild!= null && GGP.leftChild.element != null){
				BinaryNode GP = GGP.leftChild;
//				if(GGP.color == Color.RED && GP.color == Color.RED){
//					return rightRotation(GGP);
//				}
				if(GGP.leftChild.leftChild!=null && GGP.leftChild.leftChild.element!= null){
					BinaryNode P = GGP.leftChild.leftChild;
					if(GGP.leftChild.leftChild.leftChild!=null && GGP.leftChild.leftChild.leftChild.element!= null){
						BinaryNode X = GGP.leftChild.leftChild.leftChild;
						if(X.color == Color.RED && P.color == Color.RED){
							P.color = Color.BLACK;
							GP.color = Color.RED;
							GGP.leftChild = rightRotation(GP);
							
							return GGP;
						}
						if(GP.color == Color.RED && P.color == Color.RED){
							GP.color = Color.BLACK;
							GGP.color = Color.RED;
							return rightRotation(GGP);
						}
					}else{
						if(P.color == Color.RED && GP.color == Color.RED){
							GP.color = Color.BLACK;
							GGP.color = Color.RED;
							return rightRotation(GGP);
						}
					}
					if(GGP.leftChild.leftChild.rightChild!=null && GGP.leftChild.leftChild.rightChild.element!= null){
						BinaryNode X = GGP.leftChild.leftChild.rightChild;
						if(X.color == Color.RED && P.color == Color.RED){
							X.color = Color.BLACK;
							GP.color = Color.RED;
							GGP.leftChild = doubleRightRotation(GP);
							return GGP;
						}
						if(GP.color == Color.RED && P.color == Color.RED){
							GP.color = Color.BLACK;
							GGP.color = Color.RED;
							return rightRotation(GGP);
						}
						
					}
					else{
						if(P.color == Color.RED && GP.color == Color.RED){
							GP.color = Color.BLACK;
							GGP.color = Color.RED;
							return rightRotation(GGP);
						}
					}
				}
				if(GGP.leftChild.rightChild!=null && GGP.leftChild.rightChild.element!= null){
//					if(GGP.color == Color.RED && GP.color == Color.RED){
//						return leftRotation(GGP);
//					}
					BinaryNode P = GGP.leftChild.rightChild;
					if(GGP.leftChild.rightChild.leftChild!=null && GGP.leftChild.rightChild.leftChild.element!= null){
						BinaryNode X =GGP.leftChild.rightChild.leftChild;
						if(X.color == Color.RED && P.color == Color.RED){
							X.color = Color.BLACK;
							GP.color = Color.RED;
							GGP.leftChild = doubleLeftRotation(GP);
							return GGP;
						}
						if(GP.color == Color.RED && P.color == Color.RED){
							P.color = Color.BLACK;
							GGP.color = Color.RED;
							return doubleRightRotation(GGP);
						}
						
					}
					else{
						if(P.color == Color.RED && GP.color == Color.RED){
							P.color = Color.BLACK;
							GGP.color = Color.RED;
							return doubleRightRotation(GGP);
						}
					}
					if(GGP.leftChild.rightChild.rightChild!=null && GGP.leftChild.rightChild.rightChild.element!= null){
						BinaryNode X =GGP.leftChild.rightChild.rightChild;
						if(X.color == Color.RED && P.color == Color.RED){
							P.color = Color.BLACK;
							GP.color = Color.RED;
							GGP.leftChild = leftRotation(GP);
							return GGP;
						}
						if(P.color == Color.RED && GP.color == Color.RED){
							P.color = Color.BLACK;
							GGP.color = Color.RED;
							return doubleRightRotation(GGP);
						}
						
					}
					else{
						if(P.color == Color.RED && GP.color == Color.RED){
							P.color = Color.BLACK;
							GGP.color = Color.RED;
							return doubleRightRotation(GGP);
						}
					}
				}
			}
			if(GGP.rightChild!= null && GGP.rightChild.element != null){
				BinaryNode GP = GGP.rightChild;
				if(GGP.rightChild.leftChild!=null && GGP.rightChild.leftChild.element!= null){
					BinaryNode P = GGP.rightChild.leftChild;
					if(GGP.rightChild.leftChild.leftChild!=null && GGP.rightChild.leftChild.leftChild.element!= null){
						BinaryNode X = GGP.rightChild.leftChild.leftChild;
						if(X.color == Color.RED && P.color == Color.RED){
							P.color = Color.BLACK;
							GP.color = Color.RED;
							GGP.rightChild = rightRotation(GP);
							return GGP;
						}
						if(P.color == Color.RED && GP.color == Color.RED){
							P.color = Color.BLACK;
							GGP.color = Color.RED;
							return doubleLeftRotation(GGP);
						}
					}
					else{
						if(P.color == Color.RED && GP.color == Color.RED){
							P.color = Color.BLACK;
							GGP.color = Color.RED;
							return doubleLeftRotation(GGP);
						}
					}
					if(GGP.rightChild.leftChild.rightChild!=null && GGP.rightChild.leftChild.rightChild.element!= null){
						BinaryNode X = GGP.rightChild.leftChild.rightChild;
						if(X.color == Color.RED && P.color == Color.RED){
							X.color = Color.BLACK;
							GP.color = Color.RED;
							GGP.rightChild = doubleRightRotation(GP);
							return GGP;
						}
						if(P.color == Color.RED && GP.color == Color.RED){
							P.color = Color.BLACK;
							GGP.color = Color.RED;
							return doubleLeftRotation(GGP);
						}
					}
					else{
						if(P.color == Color.RED && GP.color == Color.RED){
							P.color = Color.BLACK;
							GGP.color = Color.RED;
							return doubleLeftRotation(GGP);
						}
					}
				}
				if(GGP.rightChild.rightChild!=null && GGP.rightChild.rightChild.element!= null){
					BinaryNode P = GGP.rightChild.rightChild;
					if(GGP.rightChild.rightChild.leftChild!=null && GGP.rightChild.rightChild.leftChild.element!= null){
						BinaryNode X = GGP.rightChild.rightChild.leftChild;
						if(X.color == Color.RED && P.color == Color.RED){
							X.color = Color.BLACK;
							GP.color = Color.RED;
							GGP.rightChild = doubleLeftRotation(GP);
							return GGP;
						}
						if(P.color == Color.RED && GP.color == Color.RED){
							GP.color = Color.BLACK;
							GGP.color = Color.RED;
							return leftRotation(GGP);
						}
					}
					else{
						if(P.color == Color.RED && GP.color == Color.RED){
							GP.color = Color.BLACK;
							GGP.color = Color.RED;
							return leftRotation(GGP);
						}
					}
					if(GGP.rightChild.rightChild.rightChild!=null && GGP.rightChild.rightChild.rightChild.element!= null){
						BinaryNode X = GGP.rightChild.rightChild.rightChild;
						if(X.color == Color.RED && P.color == Color.RED){
							P.color = Color.BLACK;
							GP.color = Color.RED;
							GGP.rightChild = leftRotation(GP);
							return GGP;
						}
						if(P.color == Color.RED && GP.color == Color.RED){
							GP.color = Color.BLACK;
							GGP.color = Color.RED;
							return leftRotation(GGP);
						}
					}
					else{
						if(P.color == Color.RED && GP.color == Color.RED){
							GP.color = Color.BLACK;
							GGP.color = Color.RED;
							return leftRotation(GGP);
						}
					}
				}
			}
		}
		return GGP;
		
	}
	
	
	public class BinaryNode {
		
		private Color color;
		private T element = null;
		private BinaryNode leftChild = null;
		private BinaryNode rightChild = null;
		private int height = 0;
		
		
		public BinaryNode(){
			this.color = Color.BLACK;
			this.element = null;
			this.leftChild = null;
			this.rightChild = null;
		}
		

		
		public BinaryNode(T element){
			this.color = Color.RED;
			this.element = element;
			this.leftChild = null;
			this.rightChild = null;		
		}
		
		
		public T getElement() {
			return this.element;
		}

		public Color getColor() {
			return this.color;
		}
		

		

		public BinaryNode insert(BinaryNode X, BinaryNode P, BinaryNode GP, BinaryNode GGP, MyBoolean b){
			GGP = GP;
			GP = P;
			P = this;
			if(this.element == null){
				P = X;
				if(b.getBoolean()){
					return X;
				}
				return null;
				
			}
			else if(X.element.compareTo(this.element) == 0){
				if(this.rightChild == null){
					this.rightChild = new BinaryNode(null);
				}
				b.setFalse();
				
				BinaryNode temp = this.rightChild.insert(X, P, GP, GGP, b);
				this.rightChild = balance(temp);
				
			}else if(X.element.compareTo(this.element) < 0){
				if(this.leftChild == null){
					this.leftChild = new BinaryNode(null);
				}
				this.leftChild = ColorPre(this.leftChild);
				
				BinaryNode temp = this.leftChild.insert(X, P, GP, GGP, b);
				this.leftChild = balance(temp);
				
				
				
			}else if(X.element.compareTo(this.element) > 0){

				if(this.rightChild == null){
					this.rightChild = new BinaryNode(null);
				}
				this.rightChild = ColorPre(this.rightChild);
				BinaryNode temp = this.rightChild.insert(X, P, GP, GGP, b);
				

				this.rightChild = balance(temp);
			}return this;
			
			
		}



		public int size() {
			if(this == null || this.element == null){
				return 0;
			}

			
			if(this.leftChild == null || this.leftChild.element == null){
				if(this.rightChild == null || this.rightChild.element == null){
					return 1;
				}
				return this.rightChild.size() + 1;
			}
			if(this.rightChild == null || this.rightChild.element == null){
				if(this.leftChild == null || this.leftChild.element == null){
					return 1;
				}
				return this.leftChild.size() +1;
			}
			return this.leftChild.size() + this.rightChild.size() +1;
		}



		public int getHeight() {

			if(this.leftChild == null || this.rightChild == null){
				if(this.leftChild == null && this.rightChild!= null){
					return Math.max(-1, this.rightChild.getHeight()) + 1;
				}
				if(this.rightChild == null && this.leftChild == null){
					return 0;
				}
				if(this.leftChild != null && this.rightChild == null){
					return Math.max(this.leftChild.getHeight(), -1) + 1;
				}
			}
			return Math.max(this.leftChild.getHeight(), this.rightChild.getHeight()) + 1;
		}
	}

	@Override
	public Iterator iterator() {
		return new preOrderIterator(this.root);
	}

	public boolean insert(T i) {
		MyBoolean validOperation = new MyBoolean(true); 
		BinaryNode X = new BinaryNode(i);
		this.root = ColorPre(this.root);
		
		this.root = balance(this.root.insert(X, nullNode, nullNode, nullNode, validOperation));
		this.root.color = Color.BLACK;
		return validOperation.getBoolean();
	}
	

	public Object getRotationCount() {
		
		return this.count;
	}
	public BinaryNode ColorPre(BinaryNode b){
		if(b == null){
			return null;
		}
		if(b.element == null || b.leftChild == null || b.rightChild == null){
			return b;
		}
		if(b.leftChild != null && b.rightChild != null && b.leftChild.color == Color.RED && b.rightChild.color == Color.RED){
			b.color = Color.RED;
			b.leftChild.color = Color.BLACK;
			b.rightChild.color = Color.BLACK;
		}
		return b;
	}



	public int size() {
		return this.root.size();
	}

	public int height() {
		// TODO Auto-generated method stub
		if(this.root == null){
			return -1;
		}
		return this.root.getHeight();
	}
	
	private class MyBoolean{
		public Boolean b;
		public MyBoolean(Boolean b){
			this.b = b;
		}
		public MyBoolean(){
			this.b = true;
		}
		public void setFalse(){
			this.b = false;
		}
		
		public void setTrue(){
			this.b = true;
		}
		
		public Boolean getBoolean(){
			return this.b;
		}
	}
	
	private class preOrderIterator implements Iterator<BinaryNode> {

		private MyBoolean m = new MyBoolean(); 
	    private Stack<BinaryNode> nodes;
	    private BinaryNode root;
	    private T pre = null;

	    public preOrderIterator(BinaryNode root){
	    	this.root = root;
	    	m.setFalse();
	    	nodes = new Stack<BinaryNode>();
	    	if (root != null) {
	    		nodes.push(root);
	    	}
	    }
	    public boolean hasNext() {
	    	return !nodes.isEmpty();
	    }

	    public BinaryNode next() {
	    	if (!hasNext()) throw new NoSuchElementException();
	    	BinaryNode temp = nodes.pop();
	    	if (temp.rightChild != null && temp.rightChild.element!=null) nodes.push(temp.rightChild);
	    	if (temp.leftChild != null && temp.leftChild.element!=null) nodes.push(temp.leftChild);
	    	m.setTrue();
	    	this.pre = temp.element;
	    	return temp;
	    }
		@Override
		public void remove() {
			// TODO Auto-generated method stub
			
		}
	    


	
	}
	private BinaryNode leftRotation(BinaryNode t){
		count++;
		BinaryNode temp = t.rightChild;
		t.rightChild = temp.leftChild;
		temp.leftChild = t;
		t.height = Math.max(getHeight(t.leftChild), getHeight(t.rightChild)) + 1;
		temp.height = Math.max(getHeight(temp.rightChild), getHeight(t)) + 1;
		return temp;
	}
	
	private BinaryNode rightRotation(BinaryNode t){
		count++;
		BinaryNode temp = t.leftChild;
		t.leftChild = temp.rightChild;
		temp.rightChild = t;
		t.height = Math.max(getHeight(t.leftChild), getHeight(t.rightChild)) + 1;
		temp.height = Math.max(getHeight(temp.leftChild), getHeight(t)) + 1;
		return temp;
	}
	
	private BinaryNode doubleLeftRotation(BinaryNode t){
		t.rightChild = rightRotation(t.rightChild);
		t = leftRotation(t);
		return t;
	}
	
	private BinaryNode doubleRightRotation(BinaryNode t){
		t.leftChild = leftRotation(t.leftChild);
		return rightRotation(t);
	}
}



